/*jshint esversion: 6 */
/*jshint -W030 */
import firebase from 'firebase';
export const getters = {};
