<template>
    <f7-popup id="wellcome">
        <f7-view navbar-fixed>
            <f7-pages>
                <f7-page>
                    <f7-navbar title="Quên mật khẩu">
                        <f7-nav-right>
                            <f7-link :close-popup="true">Đóng</f7-link>
                        </f7-nav-right>
                    </f7-navbar>
                    <h1>Wellcome You</h1>
                </f7-page>
            </f7-pages>
        </f7-view>
    </f7-popup>
</template>
<script>
</script>
