<template>
    <div>
        <h1>This is my qoute! {{ version }}</h1>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                version: '1.0'
            }
        }
    }
</script>