<template>
    <div style="text-align : center;">
        <h2 fill color="red" v-if="singin" @click="logout"> {{status}} logout</h2>
        <h2 fill color="red" @click="isLogin">Check</h2>
        <pre v-if="singin">Login!</pre>
        <pre v-if="!singin">Un Login!</pre>
    </div>
</template>
<script>
    import {
        mapState,
        mapMutations
    } from 'vuex'

    export default {
        data() {
            return {}
        },
        computed: {
            ...mapState(['status', 'singin'])
        },

        methods: {
            ...mapMutations(['logout', 'isLogin'])
        }
    }
</script>
<style>
</style>