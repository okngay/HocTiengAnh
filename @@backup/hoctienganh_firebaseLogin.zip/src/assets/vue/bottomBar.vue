<template>
    <div class="toolbar">
        <div class="toolbar-inner">

            <f7-button fill color="orange" open-panel="left">Tài khoản</f7-button>

            <f7-button fill color="green" open-login-screen="#login-screen">Đăng nhập </f7-button>

            <f7-button fill color="blue" open-popup="#popup">Ủng hộ</f7-button>

        </div>
    </div>
</template>