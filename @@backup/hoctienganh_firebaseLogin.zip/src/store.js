
import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);

import firebase from 'firebase';
var db = firebase.initializeApp({
    apiKey: "AIzaSyARtpjdBVtF9P-bhUVV8j9be5FDTAnO9Y8",
    authDomain: "tienganh-66025.firebaseapp.com",
    databaseURL: "https://tienganh-66025.firebaseio.com",
}).database()
var todosRef = db.ref('todos')

var myApp = new Framework7();

export const store = new Vuex.Store({
    state: {
        email: '',
        password: '',
        repassword: '',
        singin: false,
        status: 'No login',
        islogin: false
    },
    getters: {
        add: state => {
            return state.count + 2;
        },
        show: state => {
            return state.count + 3;
        }
    },
    mutations: {
        inputEmail(state, value) {
            state.email = value;
        },
        inputPassword(state, value) {
            state.password = value;
        },
        inputRePassword(state, value) {
            state.repassword = value;
        },
        isLogin(state) {
            firebase.auth().onAuthStateChanged(user => { user ? state.singin = true : state.singin = false; });
            console.log(state.singin);
        }
        ,
        check(state) {
            firebase.auth().onAuthStateChanged(function (user) {
                if (user) {
                    var email = user.email;
                    var emailVerified = user.emailVerified;
                    var uid = user.uid;
                    state.status = email;
                    state.singin = !state.singin;
                } else {
                    state.singin = false;
                }
            });
        },
        login(state) {


            var email = state.email;
            var password = state.password;
            state.islogin = true;

            //Check login
            firebase.auth().onAuthStateChanged(user => { user ? state.singin = true : state.singin = false; });
            //SingIn
            firebase.auth().signInWithEmailAndPassword(email, password)
                .then(() => {
                    setTimeout(() => { state.islogin = !state.islogin }, 1000);
                    state.singin = !state.singin;
                    myApp.addNotification({
                        title: 'Thông báo',
                        message: `Chào mừng bạn ${email}`,
                        hold: 3000
                    });
                })
                .catch(function (error) {
                    setTimeout(() => { state.islogin = !state.islogin }, 1000);
                    var errorCode = error.code;
                    var errorMessage = error.message

                    if (errorCode === 'auth/wrong-password') {
                        myApp.addNotification({
                            title: 'Thông báo',
                            message: 'Mật khẩu sai!',
                            hold: 3000
                        });
                    } else {
                        myApp.addNotification({
                            title: 'Thông báo',
                            message: 'Kiểm tra lại email, hoặc kết nối mạng của bạn đã chính xác!',
                            hold: 3000
                        });
                    }

                    console.error(error.message)
                });
        },
        logout(state) {
            state.islogin = false;
            firebase.auth().signOut()
                .then(() => {
                    state.singin = !state.singin;
                    myApp.addNotification({
                        title: 'Thông báo',
                        message: 'Bạn đã đăng xuất!',
                        hold: 3000
                    });
                }).catch(() => {
                    myApp.addNotification({
                        title: 'Thông báo',
                        message: 'Có lỗi, hãy kiểm tra kết nối mạng của bạn!',
                        hold: 3000
                    });
                    console.error(error.message)
                });
        },
        register(state) {
            firebase.auth().onAuthStateChanged(function (user) {
                if (user) {
                    state.singin = true;
                } else {
                    state.singin = false;
                }
            });
            var email = state.email;
            var password = state.password;
            var repassword = state.repassword;
            if (password == repassword && password.length > 5) {
                firebase.auth().createUserWithEmailAndPassword(email, password)
                    .then(() => {
                        myApp.addNotification({
                            title: 'Thông báo',
                            message: 'Chúc mừng bạn đã đăng ký thành công!',
                            hold: 3000
                        });
                    })
                    .catch(function (error) {
                        // Handle Errors here.
                        var errorCode = error.code;
                        var errorMessage = error.message;
                        if (errorCode == 'auth/weak-password') {
                            myApp.addNotification({
                                title: 'Thông báo',
                                message: 'Mật khẩu quá yếu, hãy chọn mật khẩu khác',
                                hold: 3000
                            });
                        } else {
                            myApp.addNotification({
                                title: 'Thông báo',
                                message: 'Kiểm tra lại email của bạn!',
                                hold: 3000
                            });
                        }
                        console.log(error);
                    });
            } else {
                myApp.addNotification({
                    title: 'Thông báo',
                    message: 'Xác nhận mật khẩu không chính xác',
                    hold: 3000
                });
            }
        },
        recoveryPass(state) {
            var email = state.email;
            firebase.auth().sendPasswordResetEmail(email)
                .then(() => {
                    myApp.addNotification({
                        title: `Đã gửi mã khôi phục đến ${email}`,
                        message: `Kiểm tra hộp thư đến trong email của bạn ngay nhé! `,
                        hold: 5000
                    });
                })
                .catch(error => {
                    console.log(error);
                    var errorCode = error.code;
                    if (error.code == "auth/user-not-found") {
                        myApp.addNotification({
                            title: 'Thông báo',
                            message: `Email ${email} chưa đăng ký!, hãy nhập email đã đăng ký !`,
                            hold: 3000
                        });
                    } else {
                        myApp.addNotification({
                            title: 'Thông báo',
                            message: `Có lỗi! Kiểm tra email, hoặc kết nối mạng của bạn!`,
                            hold: 3000
                        });
                    }

                })

        }

    }
})


store.commit('check');