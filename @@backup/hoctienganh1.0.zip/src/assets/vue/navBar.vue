<template>
    <f7-navbar>
        <f7-nav-left>
            <f7-link icon="icon-bars" open-panel="left"></f7-link>
        </f7-nav-left>
        <f7-nav-center sliding>Học Tiếng Anh</f7-nav-center>
        <f7-nav-right>
            <f7-link icon="icon-bars" open-panel="right"></f7-link>
        </f7-nav-right>
    </f7-navbar>
</template>