<template>
    <div class="toolbar">
        <div class="toolbar-inner">

            <f7-button fill color="orange" open-panel="left">Left Panel</f7-button>

            <f7-button fill color="green" open-login-screen="#login-screen">Login</f7-button>

            <f7-button fill color="blue" open-popup="#popup">Popup</f7-button>

        </div>
    </div>
</template>