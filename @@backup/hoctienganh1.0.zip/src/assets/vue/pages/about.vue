<template>
	<f7-page>
		<f7-navbar title="About" back-link="Back" sliding></f7-navbar>
		<f7-block inner>
			<p>Here is About page!</p>
			<p>You can go
				<f7-link back>back</f7-link>.</p>
			{{add}}

		</f7-block>
	</f7-page>
</template>

<script>
	import {
		mapGetters
	} from 'vuex';
	export default {
		computed: { ...mapGetters(['add'])

		}
	}
</script>