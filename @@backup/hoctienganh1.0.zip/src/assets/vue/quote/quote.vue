<template>
    <h1>This is a fking quote!</h1>
</template>
<script>
    export default {}
</script>
<style lang="sass">
</style>