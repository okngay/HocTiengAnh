
import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);
export const store = new Vuex.Store({
    state: {
        count: 0
    },
    getters: {
        add: state => {
            return state.count + 2;
        },
        show: state => {
            return state.count + 3;
        }
    },
    mutations: {
        increment(state) {
            state.count++
        }
    }
})

var arr1 = [4, 5, 6];
var arr2 = [1, 2, 3];
arr1 = [...arr2, ...arr1];

console.log(arr1);

/*store.commit('increment');
console.log(`Store hiện tại là: ` + store.state.count);*/
